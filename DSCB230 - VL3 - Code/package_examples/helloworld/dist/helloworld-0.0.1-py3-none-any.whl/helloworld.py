
def hello_world():
    print("Hello")

def test():
    print("test")